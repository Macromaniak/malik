<?php 
get_header('innerpage');
get_template_part( 'template-parts/title-section'); ?>


 <?php
get_footer('innerpage');
?>